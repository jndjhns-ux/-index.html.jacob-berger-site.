# Jacob Berger for President — Satire

A fictional/satirical campaign landing page designed for GitHub Pages.

## GitHub Pages

1. Create a **public** GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under the publishing source, select **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. Open the GitHub Pages URL shown by GitHub.

This site is explicitly fictional and does not submit real election ballots.
